import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardHomeComponent } from './components/admins/dashboard-home/dashboard-home.component';
import { ProductsComponent } from './components/admins/products/products.component';
import { OrdersComponent } from './components/admins/orders/orders.component';
import { UsersComponent } from './components/admins/users/users.component';
import { SettingsComponent } from './components/admins/settings/settings.component';
import { UserComponent } from './components/admins/user/user.component';
import { UserDashboardComponent } from './components/admins/user-dashboard/user-dashboard.component';
import { AddUserComponent } from './components/admins/add-user/add-user.component';

const routes: Routes = [
  {
    path: '',
    component: DashboardHomeComponent,
    pathMatch: 'full'
  },
  {
    path: 'home',
    component: DashboardHomeComponent
  },
  {
    path: 'products',
    component: ProductsComponent
  },
  {
    path: 'orders',
    component: OrdersComponent
  },
  {
    path: 'users',
    component: UserDashboardComponent,
    children:[
      {
        path: '',
        component: UsersComponent
      },
      {
        path: 'add',
        component: AddUserComponent
      },
      {
        path: ':userId',
        component: UserComponent
      }
    ]
  },
  // {
  //   path: 'users/:userId',
  //   component: UserComponent
  // },
  {
    path: 'settings',
    component: SettingsComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
